
import './App.css';
import Nav from './Nav';
import Sidebar from './Sidebar';


function App(){
  return(
    <div>
      {/* {nav component} */}
      <Nav/>
      <div className='app_body'>
          <Sidebar/>

          {/* Feed */}
          {/* news */}
      </div>
      
     
    </div>
  )
}
 export default App;
